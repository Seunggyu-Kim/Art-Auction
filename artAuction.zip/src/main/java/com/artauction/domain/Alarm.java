package com.artauction.domain;

import lombok.Data;

@Data
public class Alarm {

	private String userid;
	private String message;
	
}
