package com.artauction.domain;

import lombok.Data;

@Data
public class MessageVO {

	private String message;
}
